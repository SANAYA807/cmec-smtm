<?php 
$con = mysqli_connect("localhost", "root", "", "smtmi")
or die("Connection error");
?>