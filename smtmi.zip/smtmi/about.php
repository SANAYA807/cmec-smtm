<?php include "header.php"; ?>

<div class='first-div'>
    <img src='about-us.jpg'/>
    <div class='second-div'>
   
        <h2 style='position:absolute; top:20%; left:12%; color:white'>About Us</h2>
        <p style='position:absolute; top:32%; left:12%; color:white;max-width:50%'>We provide the best in class education with world class infrasturcture 
        and highly educated teachers.<br/>Our curriculum has a strong focus on individual growth and the development of essential tools so that its students make a mark in the medical world. </p>
   
      
       </div>

    </div>
</div>



    
    <section class="about inner padding-lg">
        <div class="container">
            <div class="row">
                <div class="col-md-7 left-block">
                    <h2>Who we are</h2>
                    <p>St. Mother Teresa Medical Institute  accredited and among the top institutions of the India.
                         We intend to prepare our students to be global leaders in all aspects of healthcare.
                          Our goal is not simply to create 'doctors' but 'medical scholars' impaste with a lifelong aspiration for knowledge and provision setup.</p>
                    <p>SMTMI is a great opportunity which brings you close to the frontiers and  purlieus of current scientific knowledge. This choice sets you upon a path towards the glorious profession of medicine with a unique model of medical education which we believe is second to none.</p>
                    <p></p>
                </div>
                <div class="col-md-5 about-right"> <img src="about2.jpeg" class="img-responsive" alt=""> </div>
            </div>
        </div>
    </section>

    
    <section class="why-choose grey-bg padding-lg">
        <div class="container">
            <h2><span>The Numbers Say it All</span>Why Choose Us</h2>
            <ul class="our-strength opt2">
                <li>
                    <div class="icon"><span class="icon-certification-icon"> </span></div>
                    <span class="counter">01</span>
                    <div class="title">Certified Courses</div>
                </li>
                <li>
                    <div class="icon"><span class="icon-student-icon"></span></div>
                    <span class="counter">5400</span>
                    <div class="title">Students Enrolled </div>
                </li>
                <li>
                    <div class="icon"><span class="icon-book-icon"></span></div>
                    <div class="couter-outer"><span class="counter">100</span><span>%</span></div>
                    <div class="title">Passing to Universities</div>
                </li>
                <li>
                    <div class="icon"><span class="icon-parents-icon"></span></div>
                    <div class="couter-outer"><span class="counter">100</span><span>%</span></div>
                    <div class="title">Satisfied Parents</div>
                </li>
            </ul>
        </div>
    </section>
<?php include "footer.php"; ?>