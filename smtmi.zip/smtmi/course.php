<?php include "header.php"; ?>

<div class='first-div'>
    <img src='images/course.jpg'/>
    <div class='second-div'>
   
        <h2 style='position:absolute; top:20%; left:12%; color:white'>CMS & ED</h2>
        <p style='position:absolute; top:40%; left:12%; color:white'>COMMUNITY MEDICAL SERVICE & ESSENTIAL DRUGS</p>
   
       <a href='apply-online.php'><button type="button" style=" position:absolute;top:55%;
        left:12%;background-color:#AE1111; color:white;border:none"
        class="btn btn-primary btn-lg">Apply Online</button></a>
       </div>

    </div>
</div>
    

   
    <section class="about inner padding-lg">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-md-push-5 left-block">
                    <h2>Diploma Program</h2>
                    <div class="cert-head">
                        <h3>COMMUNITY MEDICAL SERVICE & ESSENTIAL DRUGS</h3>
                    </div>
                    <p>CMS ED Course is known as diploma in community Medical Service & essential drugs (CMS & ED). It is a diploma for primary Health Care by general allopathic medicines which are recommended by world health organization (WHO) for primary health care.</p>
                    <p><strong>Eligibility : </strong>10th Pass</p>
                    <p><strong>Duration : </strong>18 Months</p>
                </div>
                <div class="col-md-5 col-md-pull-7">
                    <div class="enquire-wrapper">
                        <figure class="hidden-xs hidden-sm"><img src="images/course2.jpg" style="height:150%; " class="img-responsive" alt=""></figure>
                        <div class="enquire-now">
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include "footer.php"; ?>
