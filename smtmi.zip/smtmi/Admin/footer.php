
	</div>
	<!-- start js include path -->
	<script src="../asset/plugins/jquery/jquery.min.js"></script>
	<script src="../asset/plugins/popper/popper.js"></script>
	<script src="../asset/plugins/jquery-blockui/jquery.blockui.min.js"></script>
	<script src="../asset/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
	<!-- bootstrap -->
	<script src="../asset/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="../asset/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<script src="../asset/plugins/sparkline/jquery.sparkline.js"></script>
	<script src="../asset/js/pages/sparkline/sparkline-data.js"></script>
	<!-- Common js-->
	<script src="../asset/js/app.js"></script>
	<script src="../asset/js/layout.js"></script>
	<script src="../asset/js/theme-color.js"></script>
	<!-- material -->
	<script src="../asset/plugins/material/material.min.js"></script>
	<!--apex chart-->
	<script src="../asset/plugins/apexcharts/apexcharts.min.js"></script>
	<script src="../asset/js/pages/chart/chartjs/home-data.js"></script>
	<!-- summernote -->
	<script src="../asset/plugins/summernote/summernote.js"></script>
	<script src="../asset/js/pages/summernote/summernote-data.js"></script>
	<!-- end js include path -->
</body>


<!-- Mirrored from radixtouch.in/templates/admin/smart/source/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 26 Dec 2020 13:26:02 GMT -->
</html>